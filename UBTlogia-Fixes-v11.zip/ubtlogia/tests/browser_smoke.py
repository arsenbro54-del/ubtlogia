"""Local regression checks. Needs Playwright and Chromium, never publishes the site."""
import asyncio,json,os,shutil
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.environ.get('UBT_TEST_URL','http://127.0.0.1:8765')
REPORT=Path(os.environ.get('UBT_TEST_REPORT','/tmp/ubt-browser-report.json'))
async def main():
 checks=[];errors=[]
 async with async_playwright() as p:
  executable=os.environ.get('UBT_CHROMIUM') or shutil.which('chromium')
  browser=await p.chromium.launch(headless=True,**({'executable_path':executable} if executable else {}),args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1280,'height':900},service_workers='block')
  # External playback is a separate live check; isolate UI tests from third-party availability.
  await context.route('https://**/*',lambda r:r.abort())
  page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  def checked(name):checks.append(name);print('PASS',name)
  await page.goto(BASE)
  await page.locator('[data-authlang="ru"]').click()
  await page.locator('#guestStart').click()
  assert await page.locator('#startFull').count()==1
  checked('Guest login and dashboard')
  for route in ['subjects','tests','results','mistakes','plan','ai','profile','terms','dates','formulas']:
   await page.evaluate('(r)=>nav("/"+r)',route)
   assert len(await page.locator('#page').inner_text())>10
  checked('10 student routes render')
  topics=await page.evaluate('allTopics()')
  for lang in ['ru','kk']:
   await page.evaluate('(l)=>{state.lang=l}',lang)
   for topic in topics:
    await page.evaluate('(k)=>nav("/topic/"+encodeURIComponent(k))',topic['key'])
    assert await page.locator('#selfcheck').count()==1,topic['key']
    assert await page.locator('#lessonNote').count()==1,topic['key']
    assert await page.locator('#reportLesson').count()==1,topic['key']
    assert await page.locator('#videoSection a[href*="search_query"]').count()==0
    assert 'Для просмотра нужен интернет' not in await page.locator('#videoSection').inner_text()
    recall_text=await page.locator('.recall-item > p:first-child').all_text_contents()
    assert len(set(text.split('. ',1)[-1] for text in recall_text))==len(recall_text),topic['key']
   checked('118 lessons in '+lang+' render with check, notes and inline video controls')
  await page.evaluate('state.lang="ru";selectExamProfile(me(),"math-physics");nav("/subjects")')
  await page.locator('#onlyPhysics').click()
  assert await page.locator('[data-topic]').count()==42
  await page.locator('#theorySearch').fill('Ньютон')
  assert await page.locator('[data-topic]').count()==1
  await page.locator('[data-topic]').click()
  await page.locator('#lessonNote').fill('Моя заметка: F = ma')
  await page.locator('#bookmark').click()
  answer=await page.evaluate('theoryOf("Ньютон заңдары").check.a')
  await page.locator(f'[data-check="{(answer+1)%4}"]').click()
  assert await page.locator('#checkFeedback .feedback-incorrect').count()==1
  await page.locator('#retryCheck').click()
  await page.locator(f'[data-check="{answer}"]').click()
  assert await page.locator('#checkFeedback .feedback-correct').count()==1
  await page.locator('#markStudied').click()
  await page.reload()
  await page.evaluate('nav("/topic/"+encodeURIComponent("physics:Ньютон заңдары"))')
  assert await page.locator('#lessonNote').input_value()=='Моя заметка: F = ma'
  assert '★' in await page.locator('#bookmark').inner_text()
  assert 'Изучено' in await page.locator('#markStudied').inner_text()
  checked('Physics search, self-check, bookmark, notes and study status survive reload')
  await page.evaluate('nav("/formulas")')
  assert await page.locator('#formulaResults article').count()==42
  for lang in ['ru','kk']:
   pdf=await page.request.get(BASE+'/assets/physics-formulas-'+lang+'.pdf')
   assert pdf.status==200 and 'application/pdf' in pdf.headers['content-type']
   assert (await pdf.body()).startswith(b'%PDF-')
  assert '20' in await page.locator('#unitResult').inner_text()
  await page.locator('#unitValue').fill('1');await page.locator('#unitFrom').select_option('cm2')
  assert '0,0001' in await page.locator('#unitResult').inner_text()
  await page.locator('#formulaSearch').fill('Ом')
  assert 0<await page.locator('#formulaResults article').count()<42
  checked('Formula search, square-unit conversion and both downloadable PDFs')
  await page.evaluate('nav("/topic/"+encodeURIComponent("physics:Түзусызықты қозғалыс"))')
  before=await page.locator('#motionValues').inner_text()
  await page.locator('#motionA').fill('3')
  assert before!=await page.locator('#motionValues').inner_text()
  checked('Interactive motion graph responds to controls')
  await page.evaluate('nav("/topic/"+encodeURIComponent("math:Теңдеулер жүйесі"))')
  assert 'ETs_AJjT3C8' not in await page.evaluate('videosOf("math","Теңдеулер жүйесі").map(v=>v.id)')
  assert await page.evaluate('videosOf("math","Теңдеулер жүйесі").every(v=>!v.general)')
  await page.evaluate('nav("/topic/"+encodeURIComponent("inf:Санау жүйелері"))')
  assert 'ETs_AJjT3C8' in await page.evaluate('videosOf("inf","Санау жүйелері").map(v=>v.id)')
  assert await page.locator('#loadVideo').is_hidden()
  assert 'youtube-nocookie.com/embed/' in await page.locator('#lessonPlayer').get_attribute('src')
  checked('Corrected video mapping and embed construction (playback not tested)')
  await page.evaluate('nav("/topic/"+encodeURIComponent("physics:Ньютон заңдары"))')
  await page.locator('.video-own summary').click()
  await page.locator('#vurl').fill('https://youtu.be/abcdefghijk')
  await page.locator('#addv').click()
  assert await page.locator('#videoChoice').count()==1
  await page.locator('#watchVideo').click()
  await page.reload()
  await page.evaluate('nav("/topic/"+encodeURIComponent("physics:Ньютон заңдары"))')
  assert '✓' in await page.locator('#watchVideo').inner_text()
  await page.locator('#removeOwnVideo').click()
  assert await page.locator('#videoChoice').count()==0
  checked('Personal video add, watched persistence and removal')
  # Exercise preference changes through the actual controls, including saved profile checkboxes.
  await page.evaluate('nav("/tests")')
  await page.locator('#examProfile').select_option('math-inf')
  assert await page.locator('#practiceSubject option[value="inf"]').count()==1
  assert await page.locator('#practiceSubject option[value="physics"]').count()==0
  await page.locator('#examProfile').select_option('math-physics')
  assert await page.locator('#practiceSubject option[value="inf"]').count()==0
  assert await page.locator('#practiceSubject option[value="physics"]').count()==1
  await page.evaluate('nav("/subjects")')
  assert await page.locator('#subjectFilter option[value="inf"]').count()==0
  assert await page.locator('#subjectFilter option[value="physics"]').count()==1
  await page.locator('#libraryScope').select_option('all')
  assert await page.locator('[data-topic]').count()==118
  await page.locator('#libraryScope').select_option('mine')
  assert await page.locator('[data-topic^="inf:"]').count()==0
  await page.evaluate('nav("/profile")')
  await page.locator('[name=p-subj][value="physics"]').uncheck()
  await page.locator('[name=p-subj][value="inf"]').check()
  await page.locator('#saveP').click()
  assert await page.evaluate('me().examProfile')=='math-inf'
  await page.reload()
  await page.evaluate('nav("/tests")')
  assert await page.locator('#examProfile').input_value()=='math-inf'
  assert await page.locator('#practiceSubject option[value="physics"]').count()==0
  checked('Physics/informatics switch updates training, library, saved profile and reload')
  # Provider protocol tests use synthetic messages; these do not establish external playback.
  await page.evaluate('''()=>{
   window.__testVideoKey="physics:Ньютон заңдары";
   VIDEOS[window.__testVideoKey]=[
    {id:"rutube:e3c790a176e7b6841df1fe17c298f45a",lang:"ru",title:{ru:"Тестовый источник A",kk:"Сынақ A"}},
    {id:"vimeo:123456789",lang:"ru",title:{ru:"Тестовый источник B",kk:"Сынақ B"}}
   ];nav("/topic/"+encodeURIComponent(window.__testVideoKey));
  }''')
  assert 'rutube.ru/play/embed/' in await page.locator('#lessonPlayer').get_attribute('src')
  await page.evaluate('''()=>{
   const frame=document.querySelector('#lessonPlayer');
   window.dispatchEvent(new MessageEvent('message',{origin:'https://evil.test',source:frame.contentWindow,data:{type:'player:playComplete'}}));
  }''')
  assert not await page.evaluate('isWatched("rutube:e3c790a176e7b6841df1fe17c298f45a")')
  await page.evaluate('''()=>{
   const frame=document.querySelector('#lessonPlayer');
   window.dispatchEvent(new MessageEvent('message',{origin:'https://rutube.ru',source:frame.contentWindow,data:{type:'player:playComplete'}}));
  }''')
  assert await page.evaluate('isWatched("rutube:e3c790a176e7b6841df1fe17c298f45a")')
  await page.evaluate('''()=>{
   const frame=document.querySelector('#lessonPlayer');
   window.dispatchEvent(new MessageEvent('message',{origin:'https://rutube.ru',source:frame.contentWindow,data:{type:'player:error'}}));
  }''')
  await page.wait_for_function('document.querySelector("#lessonPlayer")?.src.includes("player.vimeo.com")')
  await page.evaluate('''()=>{
   const frame=document.querySelector('#lessonPlayer');
   window.dispatchEvent(new MessageEvent('message',{origin:'https://player.vimeo.com',source:frame.contentWindow,data:{event:'ended'}}));
  }''')
  assert await page.evaluate('isWatched("vimeo:123456789")')
  await page.locator('#nextSource').click()
  assert 'rutube.ru/play/embed/' in await page.locator('#lessonPlayer').get_attribute('src')
  await page.evaluate('delete VIDEOS[window.__testVideoKey]')
  checked('Rutube/Vimeo embedded player, automatic fallback, completion and spoofed-message rejection (simulated)')
  # Exercise random composition repeatedly; each run checks counts and point totals.
  data=await page.evaluate('''()=>{
   const out={};for(const profile of ['math-inf','math-physics']){
    for(let i=0;i<50;i++){const qs=buildFullTest(profile);if(qs.length!==120||new Set(qs.map(q=>q.id)).size!==120||qs.reduce((n,q)=>n+maxQuestionPoints(q),0)!==140)throw Error('composition');const expected=profile==='math-physics'?'physics':'inf';if(qs.filter(q=>q.s===expected).length!==40)throw Error('profile')}
    out[profile]='50 compositions passed'
   }return out
  }''')
  checked('100 full-test compositions: 120 distinct tasks, 140 points, correct profile')
  await page.evaluate('nav("/tests")')
  await page.locator('#examProfile').select_option('math-physics')
  await page.locator('[data-mode="full"]').click()
  assert await page.evaluate('state.test.qs.filter(q=>q.s==="physics").length')==40
  await page.locator('[data-answer]').first.click()
  await page.reload()
  await page.evaluate('nav("/tests")')
  await page.locator('#resume').click()
  assert await page.evaluate('state.test.qs.length')==120
  assert await page.evaluate('state.test.ans.filter(x=>x!==null&&x!==undefined).length')==1
  page.once('dialog',lambda d:d.accept())
  await page.locator('#finishNow').click()
  assert await page.locator('.result-answer').count()==120
  checked('Physics full-test selection, answer persistence, resume and finish with skipped multiple answers')
  # A physics practice lesson must remain usable even if excluded from quick-test preferences.
  await page.evaluate('me().subjects=["math"];startTest(me(),"topic",{subject:"physics",topic:"Ньютон заңдары"})')
  assert await page.evaluate('state.test.qs.every(q=>q.s==="physics")')
  # Topic practice can legitimately start with any supported question type.
  if await page.locator('[data-answer]').count():
   await page.locator('[data-answer]').first.click()
  elif await page.locator('[data-multi]').count():
   await page.locator('[data-multi]').first.check()
  else:
   for select in await page.locator('[data-match]').all():await select.select_option('0')
  await page.locator('#checkAnswer').click()
  assert await page.locator('.answer-feedback').count()==1
  await page.evaluate('nav("/tests")')
  checked('Explicit topic practice ignores unrelated quick-test preference')
  await page.evaluate('nav("/topic/%broken")')
  assert 'Тема не найдена' in await page.locator('#page').inner_text()
  checked('Malformed lesson URL is handled')
  # Export/import must preserve results including skipped multi-answer tasks.
  await page.evaluate('nav("/profile")')
  async with page.expect_download() as download_info:
   await page.locator('#expBtn').click()
  downloaded=await download_info.value
  backup=await downloaded.path()
  data=json.loads(Path(backup).read_text())
  assert len(data['attempts'])==1
  data['learning']['physics:Ньютон заңдары']['note']='Восстановленная заметка'
  restored=Path('/tmp/ubt-test-progress.json');restored.write_text(json.dumps(data,ensure_ascii=False))
  await page.locator('#impFile').set_input_files(str(restored))
  await page.wait_for_function('me().learning["physics:Ньютон заңдары"].note==="Восстановленная заметка"')
  assert await page.evaluate('me().attempts.length')==1
  checked('Export/import preserves skipped answers, notes and deduplicates attempts')
  # Phone layouts and the menu must remain operable.
  await page.set_viewport_size({'width':390,'height':844})
  for route in ['subjects','formulas','tests','profile']:
   await page.evaluate('(r)=>nav("/"+r)',route)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),route
  await page.evaluate('nav("/topic/"+encodeURIComponent("physics:Түзусызықты қозғалыс"))')
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  await page.locator('#burger').click()
  assert await page.locator('#sidebar').evaluate('(el)=>el.classList.contains("open")')
  await page.locator('#sidebar [data-nav="/formulas"]').click()
  assert await page.locator('#formulaSearch').count()==1
  checked('390px mobile layout and navigation')
  assert not errors,errors
  checked('No uncaught browser errors')
  await context.close()
  # Verify offline shell and all newly split scripts, using a real service worker.
  offline=await browser.new_context()
  await offline.route('https://**/*',lambda r:r.abort())
  pg=await offline.new_page();pg.on('pageerror',lambda e:errors.append(str(e)))
  await pg.goto(BASE)
  await pg.locator('#guestStart').click()
  await pg.evaluate('navigator.serviceWorker.ready')
  await pg.wait_for_function('navigator.serviceWorker.controller!==null')
  await pg.evaluate('nav("/topic/"+encodeURIComponent("physics:Ньютон заңдары"))')
  await offline.set_offline(True)
  await pg.goto(BASE+'/index.html')
  await pg.wait_for_selector('#startFull')
  await pg.evaluate('nav("/formulas")')
  assert await pg.locator('#formulaResults article').count()==42
  pdf=await pg.evaluate('fetch("/assets/physics-formulas-ru.pdf").then(async r=>({status:r.status,type:r.headers.get("content-type"),bytes:(await r.arrayBuffer()).byteLength}))')
  assert pdf['status']==200 and 'application/pdf' in pdf['type'] and pdf['bytes']>10000
  checked('Offline reload loads physics files and formula PDF through the service worker')
  assert not errors,errors
  await offline.close();await browser.close()
 REPORT.write_text(json.dumps({'passed':checks,'count':len(checks),'browser_errors':errors,'external_playback':'not tested'},ensure_ascii=False,indent=2))
 print('Passed checks:',len(checks),'Report:',REPORT)
if __name__=='__main__':asyncio.run(main())
