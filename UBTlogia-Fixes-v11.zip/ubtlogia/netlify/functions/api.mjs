import {getStore} from '@netlify/blobs';
import {createAPI} from '../../server/core.mjs';
export default async(req,context)=>{
 const store=getStore({name:'ubt-pro-accounts-v1',consistency:'strong'});
 return createAPI(store)(req,context);
};
