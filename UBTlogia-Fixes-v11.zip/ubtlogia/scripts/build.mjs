import {mkdir,copyFile,rm,cp} from 'node:fs/promises';
await rm('public',{recursive:true,force:true});await mkdir('public',{recursive:true});
for(const file of ['index.html','sw.js','manifest.json'])await copyFile(file,'public/'+file);
await cp('content','public/content',{recursive:true});
await cp('assets','public/assets',{recursive:true});
console.log('ҰБТлогия: public files built');
