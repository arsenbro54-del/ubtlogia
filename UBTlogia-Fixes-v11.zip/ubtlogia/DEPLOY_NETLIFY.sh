#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
npm ci
if [[ ! -f .netlify/state.json ]]; then
npx --yes netlify-cli login
printf "%s\n" "Select your EXISTING ubtlogia project."
npx --yes netlify-cli link
fi
npx --yes netlify-cli deploy --build --prod
