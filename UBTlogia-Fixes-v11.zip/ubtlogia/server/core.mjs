import {randomBytes,randomUUID,scryptSync,timingSafeEqual,createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
const str=(x,n=100)=>typeof x==='string'?x.slice(0,n):'';
const object=x=>x&&typeof x==='object'&&!Array.isArray(x)?x:{};
const subjects=['math','mathlit','inf','hist','read','physics'];
const validVideo=id=>typeof id==='string'&&(/^[\w-]{11}$/.test(id)||/^rutube:[a-f0-9]{32}$/.test(id)||/^vimeo:[0-9]{6,12}$/.test(id));
const day=()=>new Date().toISOString().slice(0,10);
const makePassword=p=>{const salt=randomBytes(16).toString('hex');return {salt,hash:scryptSync(p,salt,32,{N:16384,r:8,p:1,maxmem:64*1024*1024}).toString('hex')}};
const passwordOK=(p,v)=>{try{return timingSafeEqual(Buffer.from(v.hash,'hex'),scryptSync(p,v.salt,32,{N:16384,r:8,p:1,maxmem:64*1024*1024}))}catch{return false}};
const validPassword=p=>typeof p==='string'&&p.length>=8&&p.length<=128;
const validId=x=>typeof x==='string'&&/^[\w:-]{1,120}$/.test(x);
const finite=(x,min,max,def=0)=>Number.isFinite(x)?Math.max(min,Math.min(max,x)):def;
function userNew(email,name){
 return {id:randomUUID(),email,name,role:'student',cls:'11',city:'',subjects:subjects.filter(s=>s!=='physics'),target:120,examDate:'',examProfile:'math-inf',created:day(),attempts:[],progress:{},mistakes:[],learning:{},reviews:{},videos:{},watched:[],streak:{count:0,last:null},achievements:[],planDone:{},planBest:{},planV:2,settingsTimes:{},revision:0};
}
function reconcileSubjectChoice(u){
 const selected=Array.isArray(u.subjects)?u.subjects.filter(s=>subjects.includes(s)):subjects.filter(s=>s!=='physics');
 const profileIsNewer=(u.settingsTimes?.examProfile||0)>=(u.settingsTimes?.subjects||0);
 if(selected.some(s=>s==='inf'||s==='physics')&&profileIsNewer&&['math-inf','math-physics'].includes(u.examProfile)){
  const chosen=u.examProfile==='math-physics'?'physics':'inf',other=chosen==='physics'?'inf':'physics';
  u.subjects=[...new Set([...selected.filter(s=>s!==other),chosen])];
 }else{
  u.subjects=selected;
  if(selected.includes('physics')&&!selected.includes('inf'))u.examProfile='math-physics';
  else if(selected.includes('inf')&&!selected.includes('physics'))u.examProfile='math-inf';
  if(selected.includes('physics')&&selected.includes('inf'))u.subjects=selected.filter(s=>s!==(u.examProfile==='math-physics'?'inf':'physics'));
 }
 return u;
}
function publicUser(record){return reconcileSubjectChoice(structuredClone(record.user))}
function cleanAttempt(a){
 if(!validId(a?.id)||!Number.isFinite(a.date)||a.date<0||a.date>Date.now()+60000)return null;
 const detail=(Array.isArray(a.detail)?a.detail:[]).slice(0,120).filter(d=>validId(d?.qid)&&subjects.includes(d.s)&&typeof d.t==='string').map(d=>({
  qid:d.qid,s:d.s,t:str(d.t,120),ok:!!d.ok,ua:Array.isArray(d.ua)?d.ua.slice(0,6).map(x=>finite(x,-1,20,-1)):finite(d.ua,-1,20,-1),
  points:finite(d.points,0,2),max:finite(d.max,1,2,1)
 }));
 const points=detail.reduce((n,d)=>n+d.points,0),maxPoints=detail.reduce((n,d)=>n+d.max,0);
 return {id:a.id,date:a.date,profile:['math-inf','math-physics'].includes(a.profile)?a.profile:null,kind:['full','diagnostic','review','topic','quick','subject','daily','mistakes'].includes(a.kind)?a.kind:'quick',mode:str(a.mode,100),correct:detail.filter(d=>d.ok).length,total:detail.length,points,maxPoints,pct:maxPoints?Math.round(points/maxPoints*100):0,secs:finite(a.secs,0,86400),detail};
}
function recompute(u){
 const p={};for(const a of u.attempts)for(const d of a.detail){const k=d.s+':'+d.t;const r=p[k]??={correct:0,total:0};r.total++;if(d.ok)r.correct++}
 for(const [k,v] of Object.entries(u.legacyProgress||{})){const r=p[k]??={correct:0,total:0};r.correct+=v.correct;r.total+=v.total}
 u.progress=p;
 const latest=new Map();for(const a of u.attempts)for(const d of a.detail)latest.set(d.qid,{...d,date:a.date});
 u.mistakes=[...latest.values()].filter(d=>!d.ok).map(d=>({qid:d.qid,s:d.s,t:d.t,ua:d.ua,date:d.date,fixed:false}));
 const days=[...new Set(u.attempts.filter(a=>a.total).map(a=>{const d=new Date(a.date);return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}))].sort();
 let count=0,prior;for(const d of days){const stamp=Date.parse(d+'T12:00:00Z');count=prior&&stamp-prior===86400000?count+1:1;prior=stamp}
 u.streak={count,last:days.at(-1)||null};
}
function merge(u,raw){
 reconcileSubjectChoice(u);
 const d=object(raw);const now=Date.now(),settings=object(d.settings),times=object(d.settingsTimes);
 for(const k of ['name','city','cls','target','examDate']){
  if(settings[k]===undefined)continue;const ts=finite(times[k],0,now+60000,now);
  if(ts<(u.settingsTimes[k]||0))continue;
  if(['name','city','cls','examDate'].includes(k))u[k]=str(settings[k],k==='examDate'?10:100);
  if(k==='name'&&!u.name)u.name='Ученик';
  if(k==='target')u.target=finite(settings[k],0,140,120);
  u.settingsTimes[k]=ts;
 }
 // The profile and subject selection are one preference across devices.
 const oldTime=Math.max(u.settingsTimes.subjects||0,u.settingsTimes.examProfile||0);
 const subTime=finite(times.subjects,0,now+60000,now),profileTime=finite(times.examProfile,0,now+60000,now);
 const selected=Array.isArray(settings.subjects)?[...new Set(settings.subjects.filter(s=>subjects.includes(s)))]:[];
 const hasSubjects=selected.length>0&&subTime>=oldTime;
 const hasProfile=['math-inf','math-physics'].includes(settings.examProfile)&&profileTime>=oldTime;
 let preferenceTime=oldTime;
 if(hasSubjects){
  u.subjects=selected;preferenceTime=subTime;
  if(selected.includes('physics')&&!selected.includes('inf'))u.examProfile='math-physics';
  else if(selected.includes('inf')&&!selected.includes('physics'))u.examProfile='math-inf';
 }
 if(hasProfile&&(!hasSubjects||profileTime>=subTime)){
  u.examProfile=settings.examProfile;preferenceTime=profileTime;
  const chosen=u.examProfile==='math-physics'?'physics':'inf',other=chosen==='physics'?'inf':'physics';
  u.subjects=[...new Set([...u.subjects.filter(s=>s!==other),chosen])];
 }
 if(hasSubjects||hasProfile)u.settingsTimes.subjects=u.settingsTimes.examProfile=preferenceTime;
 const seen=new Set(u.attempts.map(a=>a.id));for(const a of (Array.isArray(d.attempts)?d.attempts:[]).slice(0,50)){const c=cleanAttempt(a);if(c&&!seen.has(c.id)){u.attempts.push(c);seen.add(c.id)}}
 u.attempts=u.attempts.sort((a,b)=>a.date-b.date).slice(-500);
 for(const [key,v] of Object.entries(object(d.learning)).slice(0,100)){
  if(key.length>200||!subjects.some(s=>key.startsWith(s+':')))continue;
  const t=finite(v?.updatedAt,0,now+60000,now);if(t<(u.learning[key]?.updatedAt||0))continue;
  u.learning[key]={done:!!v.done,bookmark:!!v.bookmark,note:str(v.note,10000),checkPassed:!!v.checkPassed,updatedAt:t};
 }
 for(const [key,v] of Object.entries(object(d.reviews)).slice(0,1000)){
  if(!validId(key))continue;const t=finite(v?.updatedAt,0,now+60000,now);if(t<(u.reviews[key]?.updatedAt||0))continue;
  u.reviews[key]={level:finite(v.level,0,5),due:finite(v.due,0,now+365*864e5),updatedAt:t};
 }
 u.watchedState??={};u.videosTimes??={};
 for(const id of u.watched||[])u.watchedState[id]??={watched:true,updatedAt:0};
 for(const id of (Array.isArray(d.watched)?d.watched:[]))if(validVideo(id)&&!u.watchedState[id])u.watchedState[id]={watched:true,updatedAt:0};
 for(const [id,v] of Object.entries(object(d.watchedState)).slice(0,1000)){
  if(!validVideo(id)||typeof v?.watched!=='boolean')continue;
  const t=finite(v.updatedAt,0,now+60000,now);if(t<(u.watchedState[id]?.updatedAt||0))continue;
  u.watchedState[id]={watched:v.watched,updatedAt:t};
 }
 u.watched=Object.keys(u.watchedState).filter(id=>u.watchedState[id].watched).slice(-1000);
 for(const [k,v] of Object.entries(object(d.videos)).slice(0,100)){
  if(k.length>200||!Array.isArray(v))continue;
  const t=object(d.videosTimes)[k],items=v.filter(x=>validVideo(x?.id)).map(x=>({id:x.id,title:{ru:str(x.title?.ru,200),kk:str(x.title?.kk,200)}}));
  if(Number.isFinite(t)){if(t<(u.videosTimes[k]||0))continue;u.videos[k]=items.filter((x,i,a)=>a.findIndex(v=>v.id===x.id)===i).slice(-12);u.videosTimes[k]=finite(t,0,now+60000,now)}
  else{const ids=new Set((u.videos[k]||[]).map(v=>v.id));u.videos[k]=[...(u.videos[k]||[]),...items.filter(x=>!ids.has(x.id))].slice(-12)}
 }
 if(!u.legacyImported&&d.legacyProgress){
  u.legacyProgress={};for(const [k,v] of Object.entries(object(d.legacyProgress)).slice(0,100)){
   const total=Math.floor(finite(v?.total,0,100000));u.legacyProgress[k]={total,correct:Math.floor(finite(v?.correct,0,total))}
  }u.legacyImported=true;
 }
 recompute(u);u.revision++;return u;
}
export function createAPI(store,{secure=true}={}){
 const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
 const cookie=t=>'ubt_session='+t+'; Path=/; HttpOnly; SameSite=Lax; Max-Age='+ (t?1209600:0)+(secure?'; Secure':'');
 const read=k=>store.getWithMetadata(k,{type:'json',consistency:'strong'});
 async function mutate(k,fn){
  for(let i=0;i<6;i++){const prior=await read(k);const out=await fn(prior?.data??null);if(out===null)return null;
   const result=await store.setJSON(k,out,prior?{onlyIfMatch:prior.etag}:{onlyIfNew:true});if(result.modified)return out;
  }throw Object.assign(new Error('Retry later'),{status:409});
 }
 async function session(req){
  const token=/\bubt_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.get('cookie')||'')?.[1];if(!token)return null;
  const sk='sessions/'+sha(token),rec=(await read(sk))?.data;if(!rec||rec.expires<Date.now())return null;
  const a=await read(rec.account);if(!a||a.data.sessionVersion!==rec.version)return null;return {key:rec.account,record:a.data,sk};
 }
 async function startSession(key,record){
  const token=randomBytes(32).toString('hex');await store.setJSON('sessions/'+sha(token),{account:key,version:record.sessionVersion,expires:Date.now()+1209600000});
  return cookie(token);
 }
 async function rate(req,context,path){
  const ip=context?.ip||req.headers.get('x-nf-client-connection-ip')||'unknown';const bucket=Math.floor(Date.now()/600000);
  const key='rate/'+sha(ip+path+bucket);const limit=path.endsWith('login')?30:path==='report'?12:10;
  await mutate(key,p=>{const n=(p?.n||0)+1;if(n>limit)throw Object.assign(new Error('Too many requests. Try again later.'),{status:429});return {n}});
 }
 return async(req,context={})=>{
  try{
   const url=new URL(req.url),path=url.pathname.replace(/^\/(?:api|\.netlify\/functions\/api)\/?/,'').replace(/\/$/,'');
   if(req.method==='GET'&&path==='health')return json({accounts:true,version:8});
   if(req.method==='GET'&&path==='me'){const s=await session(req);return s?json({user:publicUser(s.record)}):json({error:'Sign in'},401)}
   if(req.method!=='POST')return json({error:'Not found'},404);
   const origin=req.headers.get('origin');if(origin&&origin!==url.origin)return json({error:'Origin rejected'},403);
   if(!req.headers.get('content-type')?.startsWith('application/json'))return json({error:'JSON required'},415);
   const body=await req.text();if(Buffer.byteLength(body)>700000)return json({error:'Request too large'},413);
   let d;try{d=JSON.parse(body)}catch{return json({error:'Invalid JSON'},400)}d=object(d);
   if(path.startsWith('auth/')||path==='report')await rate(req,context,path);
   if(['auth/register','auth/login','auth/recover'].includes(path)){
    const email=str(d.email,254).trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json({error:'Enter a valid email'},400);
    const key='accounts/'+sha(email),existing=await read(key);let record=existing?.data,recoveryCode;
    if(path==='auth/register'){
     if(!validPassword(d.password)||!str(d.name).trim())return json({error:'Name and password of 8–128 characters required'},400);
     recoveryCode=randomBytes(24).toString('hex');record={password:makePassword(d.password),recovery:sha(recoveryCode),sessionVersion:1,user:userNew(email,str(d.name).trim())};
     const r=await store.setJSON(key,record,{onlyIfNew:true});if(!r.modified)return json({error:'Email is already registered'},409);
    }else if(path==='auth/login'){
     if(!validPassword(d.password)||!record||!passwordOK(d.password,record.password))return json({error:'Incorrect email or password'},401);
    }else{
     if(!record||typeof d.recoveryCode!=='string'||sha(d.recoveryCode.trim())!==record.recovery||!validPassword(d.password))return json({error:'Recovery code or new password is invalid'},400);
     recoveryCode=randomBytes(24).toString('hex');
     record=await mutate(key,current=>{
      if(!current||current.recovery!==record.recovery)throw Object.assign(new Error('Recovery code has changed'),{status:409});
      return {...current,password:makePassword(d.password),recovery:sha(recoveryCode),sessionVersion:current.sessionVersion+1};
     });
    }
    return json({user:publicUser(record),...(recoveryCode?{recoveryCode}:{})},200,{'Set-Cookie':await startSession(key,record)});
   }
   if(path==='report'){
    if(str(d.description,3000).trim().length<5)return json({error:'Describe the problem'},400);
    const id=validId(d.id)?d.id:randomUUID(),s=await session(req);
    await store.setJSON('reports/'+id,{id,kind:str(d.kind,30),contentId:str(d.contentId,200),description:str(d.description,3000),lang:str(d.lang,2),date:Date.now(),userId:s?.record.user.id||null},{onlyIfNew:true});
    return json({saved:true});
   }
   const s=await session(req);if(!s)return json({error:'Sign in again'},401);
   if(path==='auth/logout'){await store.delete(s.sk);return json({ok:true},200,{'Set-Cookie':cookie('')})}
   if(path==='auth/password'){
    if(!validPassword(d.password)||!passwordOK(str(d.current,128),s.record.password))return json({error:'Current password is wrong or new password is too short'},400);
    const updated=await mutate(s.key,p=>{
     if(!passwordOK(str(d.current,128),p.password))throw Object.assign(new Error('Password changed'),{status:409});
     return {...p,password:makePassword(d.password),sessionVersion:p.sessionVersion+1};
    });
    return json({ok:true},200,{'Set-Cookie':await startSession(s.key,updated)});
   }
   if(path==='sync'){
    const updated=await mutate(s.key,p=>{
     if(!p||p.sessionVersion!==s.record.sessionVersion)throw Object.assign(new Error('Sign in again'),{status:401});
     p.user=merge(p.user,d);return p;
    });return json({user:publicUser(updated)});
   }
   return json({error:'Not found'},404);
  }catch(e){return json({error:e.status?e.message:'Server unavailable'},e.status||503)}
 };
}
