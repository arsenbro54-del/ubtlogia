import http from 'node:http';
import {mkdir,readFile,writeFile,rename,unlink} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {spawn} from 'node:child_process';
import {createAPI} from './core.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const dataRoot=resolve(process.env.UBT_DATA_DIR||resolve(root,'.local-data'));
await mkdir(dataRoot,{recursive:true,mode:0o700});
const filename=k=>resolve(dataRoot,createHash('sha256').update(k).digest('hex')+'.json');
const locks=new Map();
const store={
 async getWithMetadata(k){try{return JSON.parse(await readFile(filename(k),'utf8'))}catch(e){if(e.code==='ENOENT')return null;throw e}},
 async setJSON(k,data,opts={}){
  const priorLock=locks.get(k)||Promise.resolve();let release;const own=new Promise(r=>release=r);locks.set(k,own);await priorLock;
  try{
   const prev=await this.getWithMetadata(k);
   if(opts.onlyIfNew&&prev||opts.onlyIfMatch&&prev?.etag!==opts.onlyIfMatch)return {modified:false};
   const etag=randomUUID(),tmp=filename(k)+'.'+randomUUID()+'.tmp';
   await writeFile(tmp,JSON.stringify({data,etag}),{mode:0o600});await rename(tmp,filename(k));return {modified:true,etag};
  }finally{release();if(locks.get(k)===own)locks.delete(k)}
 },
 async delete(k){try{await unlink(filename(k))}catch(e){if(e.code!=='ENOENT')throw e}}
};
const api=createAPI(store,{secure:false}),port=Number(process.env.PORT)||8765;
const staticFiles=new Map([['/','index.html'],['/index.html','index.html'],['/sw.js','sw.js'],['/manifest.json','manifest.json'],['/assets/cover-v8.png','assets/cover-v8.png'],['/assets/icon.svg','assets/icon.svg']]);
for(const asset of ["cover-v9.png", "icon-v9.png", "icon-v9-32.png", "icon-v9-192.png", "icon-v9-512.png", "icon-v9-maskable-512.png", "apple-touch-v9.png", "favicon-v9.ico", "physics-formulas-ru.pdf", "physics-formulas-kk.pdf"])staticFiles.set('/assets/'+asset,'assets/'+asset);
for(const file of ['physics.js','physics-bank.js','enhancements.js','preferences.js','video-player.js'])staticFiles.set('/content/'+file,'content/'+file);
const server=http.createServer(async(req,res)=>{
 try{
  if(!['localhost:'+port,'127.0.0.1:'+port].includes(req.headers.host)){res.writeHead(403);return res.end('Host rejected')}
  const url=new URL(req.url,'http://127.0.0.1:'+port);
  if(url.pathname.startsWith('/api/')){
   const chunks=[];let size=0;for await(const c of req){size+=c.length;if(size>700000){res.writeHead(413);return res.end('Too large')}chunks.push(c)}
   const r=await api(new Request(url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})}),{ip:req.socket.remoteAddress});
   res.writeHead(r.status,Object.fromEntries(r.headers));return res.end(Buffer.from(await r.arrayBuffer()));
  }
  const file=staticFiles.get(url.pathname);
  if(!file||!['GET','HEAD'].includes(req.method)){res.writeHead(404);return res.end('Not found')}
  const body=await readFile(resolve(root,file));
  res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.js')?'text/javascript':file.endsWith('.png')?'image/png':file.endsWith('.svg')?'image/svg+xml':file.endsWith('.ico')?'image/x-icon':file.endsWith('.pdf')?'application/pdf':'application/json','Referrer-Policy':'strict-origin-when-cross-origin','X-Content-Type-Options':'nosniff'});
  res.end(req.method==='HEAD'?'':body);
 }catch{res.writeHead(500);res.end('Server error')}
});
server.listen(port,'127.0.0.1',()=>{
 console.log('ҰБТлогия http://127.0.0.1:'+port);
 if(process.argv.includes('--open')){
  const url='http://127.0.0.1:'+port;const args=process.platform==='win32'?['cmd',['/c','start','',url]]:process.platform==='darwin'?['open',[url]]:['xdg-open',[url]];
  spawn(args[0],args[1],{stdio:'ignore',detached:true}).on('error',()=>{});
 }
});
