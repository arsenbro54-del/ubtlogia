import test from 'node:test';
import assert from 'node:assert/strict';
import {createAPI} from './core.mjs';
function setup(){
 const rows=new Map();let id=0;
 const store={async getWithMetadata(k){return rows.has(k)?structuredClone(rows.get(k)):null},async setJSON(k,data,o={}){
  const old=rows.get(k);if(o.onlyIfNew&&old||o.onlyIfMatch&&old?.etag!==o.onlyIfMatch)return {modified:false};
  const etag=String(++id);rows.set(k,{data:structuredClone(data),etag});return {modified:true,etag};
 },async delete(k){rows.delete(k)}};
 const api=createAPI(store,{secure:false});
 const call=async(path,data,cookie='',origin='http://localhost')=>{
  const r=await api(new Request('http://localhost/api/'+path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Origin:origin,...(cookie?{Cookie:cookie}:{})},...(data===undefined?{}:{body:JSON.stringify(data)})}),{ip:'test'});
  return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
 };
 return {call,rows};
}
const reg={email:'a@example.com',name:'Арсен',password:'strong-pass-123'};
test('account stores salted scrypt, no password in public data, duplicates rejected',async()=>{
 const {call,rows}=setup();const r=await call('auth/register',reg);assert.equal(r.status,200);assert.equal(r.body.recoveryCode.length,48);assert.ok(r.cookie);
 const account=[...rows.entries()].find(([k])=>k.startsWith('accounts/'))[1].data;
 assert.notEqual(account.password.hash,reg.password);assert.equal(account.password.hash.length,64);assert.ok(!JSON.stringify(r.body).includes('hash'));
 assert.equal((await call('auth/register',reg)).status,409);assert.equal((await call('auth/login',{...reg,password:'wrong123'})).status,401);
});
test('two devices union attempts and notes; account identity cannot be forged',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg);
 const attempt=id=>({id,date:Date.now(),mode:'Тест',kind:'quick',secs:10,detail:[{qid:'v7_q',s:'math',t:'Сандар',ok:true,ua:0,points:1,max:1}]});
 await Promise.all([call('sync',{id:'forged',attempts:[attempt('one')],learning:{'math:Сандар':{note:'A',done:false,bookmark:true,updatedAt:1}}},a.cookie),call('sync',{attempts:[attempt('two')],learning:{'inf:SQL':{note:'B',updatedAt:2}}},b.cookie)]);
 const u=(await call('me',undefined,a.cookie)).body.user;
 assert.equal(u.attempts.length,2);assert.equal(u.progress['math:Сандар'].total,2);assert.equal(u.learning['math:Сандар'].note,'A');assert.equal(u.learning['inf:SQL'].note,'B');assert.equal(u.id,a.body.user.id);
 await call('sync',{attempts:[attempt('one')]},b.cookie);assert.equal((await call('me',undefined,a.cookie)).body.user.attempts.length,2);
});
test('password and recovery invalidate earlier sessions including same millisecond',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg);
 const p=await call('auth/password',{current:reg.password,password:'another-pass-123'},a.cookie);assert.equal(p.status,200);
 assert.equal((await call('me',undefined,b.cookie)).status,401);
 const recover=await call('auth/recover',{email:reg.email,recoveryCode:a.body.recoveryCode,password:'third-pass-123'});
 assert.equal(recover.status,200);assert.equal((await call('me',undefined,p.cookie)).status,401);
 assert.notEqual(recover.body.recoveryCode,a.body.recoveryCode);
 assert.equal((await call('auth/recover',{email:reg.email,recoveryCode:a.body.recoveryCode,password:'fourth-pass-123'})).status,400);
});
test('CSRF, guest report, logout, invalid timestamps and private access',async()=>{
 const {call}=setup(),r=await call('auth/register',reg);
 assert.equal((await call('sync',{},r.cookie,'https://evil.example')).status,403);
 assert.equal((await call('sync',{attempts:[{id:'future',date:Date.now()+999999999}]},r.cookie)).body.user.attempts.length,0);
 assert.equal((await call('report',{id:'report-one',kind:'question',description:'Ошибка в условии',contentId:'v7_q'})).status,200);
 assert.equal((await call('auth/logout',{},r.cookie)).status,200);assert.equal((await call('me',undefined,r.cookie)).status,401);
 assert.equal((await call('unknown',{})).status,401);
});
test('watch removal and own video removal persist across devices and stale updates',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg),id='abcdefghijk';
 await call('sync',{watched:[id],watchedState:{[id]:{watched:true,updatedAt:10}},videos:{'math:Сандар':[{id,title:{ru:'Свой урок',kk:'Өз сабағым'}}]},videosTimes:{'math:Сандар':10}},a.cookie);
 assert.deepEqual((await call('me',undefined,b.cookie)).body.user.watched,[id]);
 await call('sync',{watchedState:{[id]:{watched:false,updatedAt:20}},videos:{'math:Сандар':[]},videosTimes:{'math:Сандар':20}},b.cookie);
 const stale=await call('sync',{watched:[id],watchedState:{[id]:{watched:true,updatedAt:10}},videos:{'math:Сандар':[{id}]},videosTimes:{'math:Сандар':10}},a.cookie);
 assert.deepEqual(stale.body.user.watched,[]);assert.deepEqual(stale.body.user.videos['math:Сандар'],[]);
 const marked=await call('sync',{watchedState:{[id]:{watched:true,updatedAt:30}}},a.cookie);assert.deepEqual(marked.body.user.watched,[id]);
});
test('physics profile, attempts and lesson notes survive sync on another device',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg);
 const attempt={id:'physics-attempt',date:Date.now(),kind:'full',profile:'math-physics',secs:30,detail:[{qid:'phys10_newton_calc_2',s:'physics',t:'Ньютон заңдары',ok:true,ua:1,points:1,max:1}]};
 const r=await call('sync',{settings:{subjects:['math','physics','hist','mathlit','read'],examProfile:'math-physics'},settingsTimes:{subjects:20,examProfile:20},attempts:[attempt],learning:{'physics:Ньютон заңдары':{note:'F = ma',bookmark:true,done:true,updatedAt:20}}},a.cookie);
 assert.equal(r.status,200);
 const u=(await call('me',undefined,b.cookie)).body.user;
 assert.ok(u.subjects.includes('physics'));assert.equal(u.examProfile,'math-physics');
 assert.equal(u.attempts[0].profile,'math-physics');assert.equal(u.attempts[0].detail[0].s,'physics');
 assert.deepEqual(u.progress['physics:Ньютон заңдары'],{correct:1,total:1});assert.equal(u.learning['physics:Ньютон заңдары'].note,'F = ma');
 await call('sync',{settings:{examProfile:'math-inf'},settingsTimes:{examProfile:10}},b.cookie);
 assert.equal((await call('me',undefined,a.cookie)).body.user.examProfile,'math-physics');
});

test('subject selection and exam profile stay together on both devices, including stale writes',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg);
 assert.ok(!a.body.user.subjects.includes('physics'));
 let u=(await call('sync',{settings:{examProfile:'math-physics'},settingsTimes:{examProfile:100}},a.cookie)).body.user;
 assert.ok(u.subjects.includes('physics'));assert.ok(!u.subjects.includes('inf'));
 await call('sync',{settings:{subjects:['math','inf']},settingsTimes:{subjects:90}},b.cookie);
 u=(await call('me',undefined,b.cookie)).body.user;assert.ok(!u.subjects.includes('inf'));assert.equal(u.examProfile,'math-physics');
 u=(await call('sync',{settings:{subjects:['math','inf']},settingsTimes:{subjects:110}},b.cookie)).body.user;
 assert.equal(u.examProfile,'math-inf');assert.deepEqual(u.subjects,['math','inf']);
 u=(await call('sync',{settings:{subjects:[]},settingsTimes:{subjects:120}},a.cookie)).body.user;
 assert.deepEqual(u.subjects,['math','inf']);
});

test('Rutube and Vimeo own lessons and watched state sync without accepting arbitrary URLs',async()=>{
 const {call}=setup(),a=await call('auth/register',reg),b=await call('auth/login',reg);
 const ids=['rutube:e3c790a176e7b6841df1fe17c298f45a','vimeo:123456789'];
 const u=(await call('sync',{videos:{'physics:Ньютон заңдары':[...ids.map(id=>({id,title:{ru:'Мой урок',kk:'Менің сабағым'}})),{id:'https://evil.test/iframe'}]},videosTimes:{'physics:Ньютон заңдары':10},watched:ids},a.cookie)).body.user;
 assert.equal(u.videos['physics:Ньютон заңдары'].length,2);
 const remote=(await call('me',undefined,b.cookie)).body.user;assert.deepEqual(remote.watched,ids);
 await call('sync',{watchedState:{[ids[0]]:{watched:false,updatedAt:20}}},b.cookie);
 assert.deepEqual((await call('me',undefined,a.cookie)).body.user.watched,[ids[1]]);
});

test('version 10 inconsistent saved profile is repaired when the user returns',async()=>{
 const {call,rows}=setup(),a=await call('auth/register',reg);
 const account=[...rows.entries()].find(([k])=>k.startsWith('accounts/'))[1].data;
 account.user.examProfile='math-physics';account.user.subjects=['math','mathlit','hist','read','inf'];
 account.user.settingsTimes={subjects:10,examProfile:20};
 const u=(await call('me',undefined,a.cookie)).body.user;
 assert.equal(u.examProfile,'math-physics');assert.ok(u.subjects.includes('physics'));assert.ok(!u.subjects.includes('inf'));
 const saved=(await call('sync',{},a.cookie)).body.user;
 assert.deepEqual(saved.subjects,u.subjects);
});
