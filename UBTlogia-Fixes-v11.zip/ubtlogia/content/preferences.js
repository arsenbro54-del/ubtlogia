'use strict';
function activeSubjects(u){
 const list=[...new Set((u.subjects||[]).filter(s=>SUBJECTS[s]))];
 return list.length?list:['math','mathlit','hist','read',u.examProfile==='math-physics'?'physics':'inf'];
}
function selectExamProfile(u,profile){
 if(!['math-inf','math-physics'].includes(profile))return;
 const selected=profile==='math-physics'?'physics':'inf',excluded=selected==='physics'?'inf':'physics';
 u.subjects=[...new Set([...activeSubjects(u).filter(s=>s!==excluded),selected])];
 u.examProfile=profile;
 libraryFilters.subject='all';libraryFilters.scope='mine';
}
function profileFromSubjects(u){
 if(u.subjects.includes('physics')&&!u.subjects.includes('inf'))u.examProfile='math-physics';
 else if(u.subjects.includes('inf')&&!u.subjects.includes('physics'))u.examProfile='math-inf';
}
function reconcilePreferences(u){
 const selected=activeSubjects(u),hasProfileSubject=selected.some(s=>s==='inf'||s==='physics');
 const profileIsNewer=(u.settingsTimes?.examProfile||0)>=(u.settingsTimes?.subjects||0);
 if(hasProfileSubject&&profileIsNewer&&['math-inf','math-physics'].includes(u.examProfile)){
  const chosen=u.examProfile==='math-physics'?'physics':'inf',other=chosen==='physics'?'inf':'physics';
  u.subjects=[...new Set([...selected.filter(s=>s!==other),chosen])];
 }else{
  u.subjects=selected;profileFromSubjects(u);
  if(selected.includes('inf')&&selected.includes('physics'))u.subjects=selected.filter(s=>s!==(u.examProfile==='math-physics'?'inf':'physics'));
 }
}
const preferencesBootstrap=bootstrapData;
bootstrapData=()=>{preferencesBootstrap();users.forEach(reconcilePreferences);LS.set('users',users)};
const preferencesProfile=routes.profile;
routes.profile=(el,u)=>{
 preferencesProfile(el,u);
 const fields=[...el.querySelectorAll('[name=p-subj]')];
 for(const field of fields.filter(n=>['inf','physics'].includes(n.value)))field.onchange=()=>{
  if(field.checked)fields.find(n=>n.value===(field.value==='physics'?'inf':'physics')).checked=false;
 };
 fields[0]?.closest('label').insertAdjacentHTML('beforebegin',`<p class="muted">${L('Выбранные предметы используются в библиотеке, тренировках и плане. В библиотеке можно включить показ всех предметов.','Таңдалған пәндер кітапханада, жаттығуда және жоспарда қолданылады. Кітапханада барлық пәнді көрсетуге болады.')}</p>`);
 const save=el.querySelector('#saveP'),original=save.onclick;
 save.onclick=()=>{
  const selected=fields.filter(n=>n.checked).map(n=>n.value);
  if(!selected.length)return notify(L('Выбери хотя бы один предмет','Кемінде бір пәнді таңда'));
  u.subjects=selected;profileFromSubjects(u);libraryFilters.subject='all';libraryFilters.scope='mine';
  original();
 };
};
const preferencesWeakTopics=weakTopics;
weakTopics=(u,limit=5)=>preferencesWeakTopics(u,allTopics().length).filter(x=>activeSubjects(u).includes(x.s)).slice(0,limit);
function dueReviewCount(u){
 const selected=new Set(activeSubjects(u));
 return Object.entries(u.reviews||{}).filter(([id,r])=>r.due<=Date.now()&&selected.has(questions.find(q=>q.id===id)?.s)).length;
}
