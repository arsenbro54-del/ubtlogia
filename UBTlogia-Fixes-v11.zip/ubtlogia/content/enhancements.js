'use strict';
SUBJECTS.physics={name:{ru:'Физика',kk:'Физика'},icon:'⚛️',topics:Object.fromEntries(PHYSICS_LESSONS.map(l=>[l.name.kk,l.name]))};
SOURCES.physics='https://testcenter.kz/wp-content/uploads/2025/10/12_%D0%A4%D0%B8%D0%B7%D0%B8%D0%BA%D0%B0_%D1%80%D1%83%D1%81.pdf';
for(const l of PHYSICS_LESSONS){
 THEORY[l.name.kk]=Object.fromEntries(['ru','kk'].map(lang=>{
  const d=l[lang],ru=lang==='ru';
  return [lang,{def:d.definition,text:d.text,formulas:l.formulas,sub:[{h:ru?'Обозначения, единицы и условия':'Белгілеулер, бірліктер және шарттар',p:l.units[lang]}],
   examples:[d.q+' '+(ru?'Ответ: ':'Жауап: ')+d.o[d.a]+'. '+d.e],errors:[d.error],tips:[d.error],
   plan:ru?['Запиши данные и переведи единицы в СИ.','Выбери модель и проверь условия применения формулы.','Вырази неизвестную величину, затем подставь числа.','Проверь единицу, знак и разумность результата.']:['Берілгенін жазып, бірліктерді SI-ға ауыстыр.','Модельді таңдап, формуланың қолданылу шартын тексер.','Белгісіз шаманы өрнектеп, сандарды қой.','Өлшемді, таңбаны және нәтиженің қисындылығын тексер.'],
   check:{q:d.q,o:d.o,a:d.a,e:d.e}}];
 }));
}
// Topic associations are deliberately narrow. Variant reviews remain separate resources.
const correctedVideos={
 ETs_AJjT3C8:{s:'inf',topics:['Санау жүйелері'],title:{ru:'Системы счисления с нуля',kk:'Санау жүйелері: негіздер'}},
 '08jbdcilywE':{topics:['Логарифмдер']},'wc7-rm65ISw':{topics:['Логарифмдер']},
 zfu56vUaehc:{topics:['Логарифмдер']},kDyRtDdxyDE:{topics:['Логарифмдер','Көрсеткіштік теңдеулер']},
 h7hIt2ekYqA:{topics:['Радикалдар']},Z3iHQwrBqAM:{topics:['Жанама және экстремум']},
 iHUoanaS2GU:{topics:['Тригонометрия'],title:{ru:'Тригонометрия: подготовка к ҰБТ',kk:'Тригонометрия: ҰБТ-ға дайындық'}},
 '1n7s6_Vzlts':{topics:['Тригонометрия']},'2-UaWTauLtY':{topics:['Стереометрия']},
 '9lILbapJ6nA':{topics:['Python бағдарламалау']},lbl9nxwFWDw:{topics:['Комбинаторика']}
};
// University sequence limits are not a lesson on arithmetic/geometric progressions.
const removed=VIDEO_CATALOG.findIndex(v=>v.id==='ZmwdHAhVsPM');if(removed>=0)VIDEO_CATALOG.splice(removed,1);
for(const v of VIDEO_CATALOG)if(correctedVideos[v.id])Object.assign(v,correctedVideos[v.id]);
for(const k of Object.keys(VIDEOS))delete VIDEOS[k];for(const k of Object.keys(CH))delete CH[k];
for(const v of VIDEO_CATALOG){if(v.general)(CH[v.s]??=[]).push(v);else for(const tp of v.topics)(VIDEOS[v.s+':'+tp]??=[]).push(v)}
// A general variant must not masquerade as a lesson for an unrelated topic.
videosOf=(s,tp)=>{
 const list=[...(VIDEOS[s+':'+tp]||[]),...(LS.get(myVideosKey(),{})[s+':'+tp]||[])];
 return list.filter((v,i)=>validVideo(v?.id)&&list.findIndex(x=>x.id===v.id)===i);
};
const sectionNames={
 mechanics:{ru:'Механика',kk:'Механика'},waves:{ru:'Колебания и волны',kk:'Тербелістер және толқындар'},
 thermal:{ru:'Молекулярная физика и термодинамика',kk:'Молекулалық физика және термодинамика'},
 electricity:{ru:'Электричество',kk:'Электр'},electromagnetism:{ru:'Магнетизм и электромагнитные колебания',kk:'Магнетизм және электромагниттік тербелістер'},
 optics:{ru:'Оптика',kk:'Оптика'},modern:{ru:'Современная физика',kk:'Заманауи физика'},astronomy:{ru:'Астрономия и космология',kk:'Астрономия және космология'}
};
function examProfileControl(el,u){
 const host=el.querySelector('#startFull')?.closest('.card')||el.querySelector('[data-mode="full"]')?.closest('.card');if(!host)return;
 host.insertAdjacentHTML('afterbegin',`<label for="examProfile">${L('Профиль пробника','Сынақ бейіні')}<select id="examProfile"><option value="math-inf">${L('Математика + информатика','Математика + информатика')}</option><option value="math-physics">${L('Математика + физика','Математика + физика')}</option></select></label>`);
 const select=host.querySelector('#examProfile');select.value=u.examProfile||'math-inf';select.onchange=()=>{selectExamProfile(u,select.value);LS.set('users',users);render()};
}
for(const route of ['tests','dashboard']){const base=routes[route];routes[route]=(el,u)=>{base(el,u);examProfileControl(el,u)}}
const expandedLibrary=routes.subjects;
routes.subjects=(el,u)=>{
 expandedLibrary(el,u);
 if(!activeSubjects(u).includes('physics')&&libraryFilters.scope!=='all')return;
 el.querySelector('.theory-hero').insertAdjacentHTML('afterend',`<section class="card physics-feature"><span class="eyebrow">⚛️ ${L('Физика ҰБТ','ҰБТ физикасы')}</span><h3>${L('От первой формулы до ядерных реакций','Алғашқы формуладан ядролық реакцияға дейін')}</h3><p>${PHYSICS_LESSONS.length} ${L('тем: теория, единицы СИ, условия формул, разборы и практика.','тақырып: теория, SI бірліктері, формула шарттары, талдау және жаттығу.')}</p><div class="row"><button class="btn" id="onlyPhysics">${L('Открыть физику','Физиканы ашу')}</button><button class="btn ghost" data-nav="/formulas">${L('Справочник формул','Формулалар анықтамалығы')}</button></div></section>`);
 el.querySelector('#onlyPhysics').onclick=()=>{const filter=el.querySelector('#subjectFilter');filter.value='physics';filter.dispatchEvent(new Event('change'));el.querySelector('#topicResults').scrollIntoView({behavior:'smooth'})};
};
const expandedTopic=routes.topic;
routes.topic=(el,u)=>{
 READY.player?.destroy?.();READY.player=null;
 expandedTopic(el,u);
 let key;try{key=decodeURIComponent(state.route.split('/topic/')[1]||'')}catch{return}
 const colon=key.indexOf(':'),s=key.slice(0,colon),tp=key.slice(colon+1),section=el.querySelector('#videoSection');if(!section||!SUBJECTS[s]?.topics[tp])return;
 if(s==='physics'){
  section.insertAdjacentHTML('beforeend',`<details class="worked"><summary>${L('Официальные материалы ҰБТ','ҰБТ ресми материалдары')}</summary><p><a href="${SOURCES.physics}" target="_blank" rel="noopener noreferrer">${L('Спецификация НЦТ: физика, с 2026 года','ҰТО спецификациясы: физика, 2026 жылдан')} ↗</a></p><p><a href="https://testcenter.kz/wp-content/uploads/2024/12/Fizika.pdf" target="_blank" rel="noopener noreferrer">${L('Рекомендованные учебники','Ұсынылған оқулықтар')} ↗</a></p><p><a href="https://testcenter.kz/?page_id=15094&lang=ru" target="_blank" rel="noopener noreferrer">${L('Все документы и образцы заданий','Барлық құжат пен тапсырма үлгілері')} ↗</a></p></details>`);
  const l=PHYSICS_LESSONS.find(x=>x.name.kk===tp);
  el.querySelector('.lesson-header').insertAdjacentHTML('beforeend',`<p class="muted">${esc(sectionNames[l.section][state.lang])} · <a data-nav="/formulas" href="#">${L('Все формулы','Барлық формула')} →</a></p>`);
  if(l.id==='kinematics'||l.id==='graphs')physicsMotionLab(el.querySelector('#understand'));
 }
};
function physicsMotionLab(host){
 host.insertAdjacentHTML('beforeend',`<div class="graph"><h4>${L('Лаборатория: движение с постоянным ускорением','Зертхана: тұрақты үдеумен қозғалу')}</h4><p class="muted">${L('Измени данные и проследи, как меняются скорость и перемещение.','Деректерді өзгертіп, жылдамдық пен орын ауыстыруды бақыла.')}</p><label>v₀, м/с <input type="range" id="motionV" min="0" max="10" value="2"></label><label>a, м/с² <input type="range" id="motionA" min="-2" max="4" value="1" step="0.5"></label><label>t, с <input type="range" id="motionT" min="1" max="10" value="4"></label><canvas id="motionCanvas" height="220" aria-label="${L('График координаты от времени','Координатаның уақытқа тәуелділік графигі')}"></canvas><p id="motionValues" role="status"></p></div>`);
 const draw=()=>{
  const v=+host.querySelector('#motionV').value,a=+host.querySelector('#motionA').value,t=+host.querySelector('#motionT').value;
  host.querySelector('#motionValues').textContent=`v₀ = ${v} м/с; a = ${a} м/с²; t = ${t} с → v = ${v+a*t} м/с; Δx = ${v*t+a*t*t/2} м. `+L('Δx — перемещение, не всегда путь.','Δx — орын ауыстыру, әрқашан жол емес.');
  const cv=host.querySelector('#motionCanvas'),w=cv.width=Math.max(280,cv.clientWidth)*devicePixelRatio,h=cv.height=220*devicePixelRatio,c=cv.getContext('2d'),pad=30*devicePixelRatio;
  const samples=Array.from({length:101},(_,i)=>{const u=t*i/100;return v*u+a*u*u/2}),min=Math.min(0,...samples),max=Math.max(1,...samples),range=max-min;
  const X=u=>pad+(w-2*pad)*u/t,Y=x=>h-pad-(h-2*pad)*(x-min)/range;
  c.clearRect(0,0,w,h);c.strokeStyle='#968473';c.lineWidth=devicePixelRatio;c.beginPath();c.moveTo(pad,pad);c.lineTo(pad,h-pad);c.moveTo(pad,Y(0));c.lineTo(w-pad,Y(0));c.stroke();
  c.strokeStyle='#e4572e';c.lineWidth=2*devicePixelRatio;c.beginPath();samples.forEach((x,i)=>{i?c.lineTo(X(t*i/100),Y(x)):c.moveTo(X(0),Y(x))});c.stroke();
  c.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--text');c.font=12*devicePixelRatio+'px sans-serif';c.fillText('x, м',pad,pad-8*devicePixelRatio);c.fillText('t, с',w-48*devicePixelRatio,h-6*devicePixelRatio);c.fillText(String(t),w-pad,h-pad+14*devicePixelRatio);
 };host.querySelectorAll('.graph input').forEach(n=>n.oninput=draw);draw();
}
let formulaFilters={search:'',section:'all'};
routes.formulas=(el,u)=>{
 el.classList.add("formula-reference");
 el.innerHTML=`<section class="card theory-hero"><div><span class="eyebrow">⚛️ ${L('Физика · быстрый справочник','Физика · қысқа анықтамалық')}</span><h2>${L('Формула + единицы + условия','Формула + бірлік + шарт')}</h2><p>${L('Поиск по названию, символу или закону. Открой тему для объяснения и практики.','Атау, таңба не заң бойынша ізде. Түсіндірме мен жаттығу үшін тақырыпты аш.')}</p></div><div class="row no-print"><button class="btn ghost" id="printFormulas">${L('Распечатать','Басып шығару')}</button><a class="btn ghost" id="downloadFormulas" href="./assets/physics-formulas-${state.lang}.pdf" download>${L('Скачать PDF','PDF жүктеу')} ↓</a></div></section>
 <div class="card formula-tools"><label for="formulaSearch">${L('Поиск формулы','Формула іздеу')}</label><input id="formulaSearch" type="search" value="${esc(formulaFilters.search)}" placeholder="${L('Ом, сила, энергия, λ…','Ом, күш, энергия, λ…')}"><label for="formulaSection">${L('Раздел','Бөлім')}</label><select id="formulaSection"><option value="all">${L('Все разделы','Барлық бөлім')}</option>${Object.entries(sectionNames).map(([id,n])=>`<option value="${id}" ${formulaFilters.section===id?'selected':''}>${esc(n[state.lang])}</option>`).join('')}</select></div>
 <div class="card formula-tools"><h3>${L('Перевод в СИ','SI жүйесіне ауыстыру')}</h3><div class="row"><label>${L('Значение','Мән')}<input id="unitValue" type="number" value="72" step="any"></label><label>${L('Единица','Бірлік')}<select id="unitFrom"><option value="kmh">км/ч → м/с</option><option value="cm">см → м</option><option value="cm2">см² → м²</option><option value="mm2">мм² → м²</option><option value="cm3">см³ → м³</option><option value="liter">л → м³</option><option value="gram">г → кг</option><option value="microfarad">мкФ → Ф</option><option value="celsius">°C → К</option><option value="kwh">кВт·ч → Дж</option></select></label></div><p id="unitResult" role="status"></p></div><div id="formulaResults"></div>`;
 const draw=()=>{
  const query=normalizeText(formulaFilters.search),rows=PHYSICS_LESSONS.filter(l=>(formulaFilters.section==='all'||l.section===formulaFilters.section)&&normalizeText([l.name.ru,l.name.kk,...l.formulas,l.units.ru,l.units.kk].join(' ')).includes(query));
  el.querySelector('#formulaResults').innerHTML=`<p class="muted" aria-live="polite">${L('Тем найдено','Тақырып табылды')}: ${rows.length}</p>`+rows.map(l=>`<article class="card"><span class="eyebrow">${esc(sectionNames[l.section][state.lang])}</span><h3>${esc(l.name[state.lang])}</h3><div class="th-formula-list">${l.formulas.map(f=>`<div>${esc(f)}</div>`).join('')}</div><p>${esc(l.units[state.lang])}</p><p class="muted">${esc(l[state.lang].error)}</p><button class="btn ghost sm" data-nav="/topic/${encodeURIComponent('physics:'+l.name.kk)}">${L('Разбор и практика','Талдау және жаттығу')} →</button></article>`).join('');
 };el.querySelector('#formulaSearch').oninput=e=>{formulaFilters.search=e.target.value;draw()};el.querySelector('#formulaSection').onchange=e=>{formulaFilters.section=e.target.value;draw()};el.querySelector('#printFormulas').onclick=()=>window.print();draw();
 const conversions={kmh:[1/3.6,'м/с'],cm:[.01,'м'],cm2:[1e-4,'м²'],mm2:[1e-6,'м²'],cm3:[1e-6,'м³'],liter:[.001,'м³'],gram:[.001,'кг'],microfarad:[1e-6,'Ф'],celsius:[1,'К',273.15],kwh:[3.6e6,'Дж']};
 const convert=()=>{const field=el.querySelector('#unitValue'),n=field.value.trim()===''?NaN:Number(field.value),[factor,unit,offset=0]=conversions[el.querySelector('#unitFrom').value],out=el.querySelector('#unitResult');out.textContent=Number.isFinite(n)?(n*factor+offset).toLocaleString(state.lang==='ru'?'ru-RU':'kk-KZ',{maximumSignificantDigits:12})+' '+unit:L('Введи число','Сан енгіз')};el.querySelector('#unitValue').oninput=convert;el.querySelector('#unitFrom').onchange=convert;convert();
};
