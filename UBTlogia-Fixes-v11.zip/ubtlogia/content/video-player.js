'use strict';
// Provider IDs, never arbitrary iframe markup or URLs from user input.
const VideoSources={
 valid(id){return typeof id==='string'&&(/^[\w-]{11}$/.test(id)||/^pl:[\w-]{10,100}$/.test(id)||/^rutube:[a-f0-9]{32}$/.test(id)||/^vimeo:[0-9]{6,12}$/.test(id))},
 provider(id){return id.startsWith('rutube:')?'rutube':id.startsWith('vimeo:')?'vimeo':'youtube'},
 label(id){return {youtube:'YouTube',rutube:'Rutube',vimeo:'Vimeo'}[this.provider(id)]},
 parse(input){
  if(typeof input!=='string')return null;const raw=input.trim();
  if(this.valid(raw)&&!raw.startsWith('pl:'))return raw;
  try{
   const u=new URL(raw);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return null;
   const h=u.hostname.replace(/^www\./,'').replace(/^m\./,'');let id;
   if(['youtube.com','youtube-nocookie.com','youtu.be'].includes(h)){
    id=h==='youtu.be'?u.pathname.slice(1).split('/')[0]:u.searchParams.get('v')||u.pathname.match(/^\/(?:embed|shorts|live)\/([\w-]{11})(?:\/|$)/)?.[1];
    return /^[\w-]{11}$/.test(id||'')?id:null;
   }
   if(h==='rutube.ru'){id=u.pathname.match(/^\/(?:video|play\/embed)\/([a-f0-9]{32})(?:\/|$)/)?.[1];return id?'rutube:'+id:null}
   if(['vimeo.com','player.vimeo.com'].includes(h)){id=u.pathname.match(/^\/(?:video\/)?([0-9]{6,12})(?:\/|$)/)?.[1];return id?'vimeo:'+id:null}
  }catch{}return null;
 },
 original(id){
  if(!this.valid(id))return '';
  if(id.startsWith('rutube:'))return 'https://rutube.ru/video/'+id.slice(7)+'/';
  if(id.startsWith('vimeo:'))return 'https://vimeo.com/'+id.slice(6);
  return id.startsWith('pl:')?'https://www.youtube.com/playlist?list='+encodeURIComponent(id.slice(3)):'https://www.youtube.com/watch?v='+id;
 },
 embedURL(id,{origin,lang='ru'}={}){
  if(!this.valid(id))return null;let url;
  if(id.startsWith('rutube:'))url=new URL('https://rutube.ru/play/embed/'+id.slice(7)+'/');
  else if(id.startsWith('vimeo:')){url=new URL('https://player.vimeo.com/video/'+id.slice(6));url.searchParams.set('dnt','1')}
  else{
   url=new URL(id.startsWith('pl:')?'https://www.youtube-nocookie.com/embed/videoseries':'https://www.youtube-nocookie.com/embed/'+id);
   if(id.startsWith('pl:'))url.searchParams.set('list',id.slice(3));
   for(const [k,v] of Object.entries({rel:'0',playsinline:'1',enablejsapi:'1',hl:lang}))url.searchParams.set(k,v);
   if(origin&&/^https?:\/\//.test(origin))url.searchParams.set('origin',origin);
  }
  return url.href;
 },
 mount(box,id,{title,lang='ru',onReady=()=>{},onEnded=()=>{},onError=()=>{},onTrackingUnavailable=()=>{}}={}){
  const src=this.embedURL(id,{origin:location.origin,lang});if(!src)return null;
  const frame=document.createElement('iframe');frame.id='lessonPlayer';frame.src=src;frame.title=title||'Видеоурок';
  frame.allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen';
  frame.allowFullscreen=true;frame.referrerPolicy='strict-origin-when-cross-origin';
  box.replaceChildren(frame);
  const provider=this.provider(id),expectedOrigin=new URL(src).origin;let destroyed=false,yt=null,ended=false;
  const alive=()=>!destroyed&&frame.isConnected;
  const finish=()=>{if(alive()&&!ended){ended=true;onEnded()}};
  const ready=()=>{if(alive())onReady()};
  const fail=error=>{if(alive())onError(error)};
  const listener=e=>{
   if(!alive()||e.source!==frame.contentWindow||e.origin!==expectedOrigin)return;
   let data=e.data;if(typeof data==='string'){try{data=JSON.parse(data)}catch{return}}
   if(!data||typeof data!=='object')return;
   if(provider==='rutube'){
    if(data.type==='player:ready'||data.type==='player:playStart')ready();
    if(data.type==='player:playComplete')finish();
    if(data.type==='player:error')fail(data.data||data);
   }else if(provider==='vimeo'){
    if(data.event==='ready'){
     ready();for(const event of ['ended','error'])frame.contentWindow.postMessage({method:'addEventListener',value:event},expectedOrigin);
    }
    if(data.event==='play')ready();
    if(data.event==='ended'||data.event==='finish')finish();
    if(data.event==='error')fail(data.data||data);
   }
  };
  if(provider==='youtube'){
   getYouTubeAPI().then(YT=>{
    if(!alive())return;
    yt=new YT.Player(frame,{events:{onReady:ready,onError:e=>fail({provider,code:e.data}),onStateChange:e=>{if(e.data===1)ready();if(e.data===0)finish()}}});
   }).catch(()=>{if(alive())onTrackingUnavailable()});
  }else window.addEventListener('message',listener);
  return {destroy(){destroyed=true;window.removeEventListener('message',listener);try{yt?.destroy()}catch{}if(frame.isConnected)frame.remove()}};
 }
};
