@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22+ from https://nodejs.org/
  pause
  exit /b 1
)
call npm ci
if errorlevel 1 goto fail
if exist ".netlify\state.json" goto deploy
call npx --yes netlify-cli login
if errorlevel 1 goto fail
echo Select your EXISTING ubtlogia project.
call npx --yes netlify-cli link
if errorlevel 1 goto fail
:deploy
call npx --yes netlify-cli deploy --build --prod
if errorlevel 1 goto fail
echo Deployment complete.
pause
exit /b 0
:fail
echo Deployment failed. Review the error above.
pause
exit /b 1
