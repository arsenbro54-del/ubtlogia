import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
const context=vm.createContext({});
for(const name of ['physics','physics-bank'])vm.runInContext(readFileSync(new URL('../content/'+name+'.js',import.meta.url),'utf8'),context);
const {lessons,bank}=vm.runInContext('({lessons:PHYSICS_LESSONS,bank:PHYSICS_BANK})',context);
test('all authored questions have unique IDs and valid bilingual answer choices',()=>{
 const originals=['AUTHORED_ORIGINAL','AUTHORED_BANK'].flatMap(name=>JSON.parse(html.match(new RegExp('const '+name+'=(\\[[^\\n]*\\]);'))[1]));
 const questions=[...originals,...bank],ids=new Set();
 for(const q of questions){assert.ok(!ids.has(q.id),q.id);ids.add(q.id);
  for(const lang of ['ru','kk']){const d={...q,...q.i18n?.[lang]};assert.ok(d.q&&d.e,q.id+':'+lang);
   if(q.type==='matching'){assert.equal(d.left.length,d.a.length);assert.equal(d.a.length,2);for(const a of d.a)assert.ok(Number.isInteger(a)&&a>=0&&a<d.right.length)}
   else{assert.ok(Array.isArray(d.o)&&d.o.length>=4);assert.equal(new Set(d.o).size,d.o.length,q.id);for(const a of Array.isArray(d.a)?d.a:[d.a])assert.ok(Number.isInteger(a)&&a>=0&&a<d.o.length,q.id)}
  }
 }
 assert.equal(questions.length,2180);
});
test('physics has a bilingual explanation, units, formulas and practice in every lesson',()=>{
 assert.equal(lessons.length,42);assert.equal(new Set(lessons.map(x=>x.name.kk)).size,42);
 for(const l of lessons){assert.ok(l.formulas.length>=3);for(const lang of ['ru','kk']){assert.ok(l[lang].definition&&l[lang].text&&l[lang].error&&l.units[lang]);assert.ok(l[lang].o[l[lang].a])}assert.ok(bank.filter(q=>q.t===l.name.kk).length>=5)}
 assert.equal(bank.filter(q=>q.type==='matching').length,5);assert.equal(bank.filter(q=>q.type==='multiple').length,10);assert.equal(bank.filter(q=>q.type==='context').length,10);
});
test('numeric physics answer keys obey independently calculated relations',()=>{
 const expected={units:n=>10*n,kinematics:n=>n*n,graphs:n=>2*n,projectile:n=>5*n*n,circular:n=>2*n*n,newton:n=>n,forces:n=>n,gravity:n=>n*n,statics:n=>n,fluids:n=>10*n,momentum:n=>2*n,energy:n=>n*n,oscillations:n=>n,waves:n=>n,gas:n=>273+10*n,'gas-processes':n=>100*n,thermodynamics:n=>100*(n-1),heat:n=>4200*n,matter:n=>10*n,engines:n=>10*n,electrostatics:n=>2*n,capacitors:n=>10*n,current:n=>n,circuits:n=>n,joule:n=>10*n,media:n=>2*n,magnetic:n=>n/10,induction:n=>n/10,lc:n=>n,ac:n=>100*n,'em-waves':n=>n,reflection:n=>n,lenses:n=>n,'wave-optics':n=>500*n,relativity:n=>3*n,photons:n=>n,atom:n=>n,nucleus:n=>2**n,'nuclear-energy':n=>.9315*n,nano:n=>n*1e-8,cosmology:n=>70*n,astronomy:n=>n**3};
 for(const l of lessons)for(let n=2;n<=5;n++){
  const q=bank.find(x=>x.id==='phys10_'+l.id+'_calc_'+n),text=q.i18n.ru.o[q.a],answer=Number(text.split(' ')[0].replace(',','.'));
  assert.ok(Math.abs(answer-expected[l.id](n))<Math.max(1e-15,Math.abs(expected[l.id](n))*1e-7),q.id+': '+answer);
 }
});
test('every inline and content script parses',()=>{
 for(const [i,m] of [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].entries())new vm.Script(m[1],{filename:'inline-'+i});
 new vm.Script(readFileSync(new URL('../content/enhancements.js',import.meta.url),'utf8'));
});

test('official 2026 physics specification maps all 25 topics to existing lessons',()=>{
 const spec=JSON.parse(readFileSync(new URL('../content/physics-specification.json',import.meta.url),'utf8'));
 assert.equal(spec.topics.length,25);const ids=new Set(lessons.map(l=>l.id));
 for(const t of spec.topics){assert.ok(t.lesson_ids.length);for(const id of t.lesson_ids)assert.ok(ids.has(id),id)}
 const covered=new Set(spec.topics.flatMap(t=>t.lesson_ids));for(const id of ids)assert.ok(covered.has(id),id);
});
