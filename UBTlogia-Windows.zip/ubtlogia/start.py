import http.server,webbrowser,socketserver
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  name={'/content/physics.js':'content/physics.js','/content/physics-bank.js':'content/physics-bank.js','/content/enhancements.js':'content/enhancements.js','/assets/physics-formulas-ru.pdf':'assets/physics-formulas-ru.pdf','/assets/physics-formulas-kk.pdf':'assets/physics-formulas-kk.pdf','/':'index.html','/index.html':'index.html','/sw.js':'sw.js','/manifest.json':'manifest.json','/assets/cover-v8.png':'assets/cover-v8.png','/assets/cover-v9.png':'assets/cover-v9.png','/assets/icon.svg':'assets/icon.svg','/assets/icon-v9.png':'assets/icon-v9.png','/assets/icon-v9-32.png':'assets/icon-v9-32.png','/assets/icon-v9-192.png':'assets/icon-v9-192.png','/assets/icon-v9-512.png':'assets/icon-v9-512.png','/assets/icon-v9-maskable-512.png':'assets/icon-v9-maskable-512.png','/assets/apple-touch-v9.png':'assets/apple-touch-v9.png','/assets/favicon-v9.ico':'assets/favicon-v9.ico'}.get(self.path.split('?')[0])
  if self.headers.get('Host') not in ['localhost:8765','127.0.0.1:8765']:return self.send_error(403)
  if not name:return self.send_error(404)
  b=(ROOT/name).read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8' if name.endswith('.html') else 'text/javascript' if name.endswith('.js') else 'image/png' if name.endswith('.png') else 'image/svg+xml' if name.endswith('.svg') else 'image/x-icon' if name.endswith('.ico') else 'application/pdf' if name.endswith('.pdf') else 'application/json');self.send_header('Referrer-Policy','strict-origin-when-cross-origin');self.end_headers();self.wfile.write(b)
with socketserver.TCPServer(('127.0.0.1',8765),Handler) as server:
 print('Гостевой режим: http://127.0.0.1:8765');webbrowser.open('http://127.0.0.1:8765');server.serve_forever()
