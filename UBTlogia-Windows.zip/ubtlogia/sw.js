const CACHE='ubt-pro-v10-physics-20261012';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./content/physics.js','./content/physics-bank.js','./content/enhancements.js','./assets/physics-formulas-ru.pdf','./assets/physics-formulas-kk.pdf','./manifest.json','./assets/cover-v9.png','./assets/icon.svg','./assets/icon-v9-32.png','./assets/icon-v9-192.png','./assets/icon-v9-512.png','./assets/icon-v9-maskable-512.png','./assets/apple-touch-v9.png','./assets/favicon-v9.ico']))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('ubt-pro-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('message',e=>{if(e.data==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET')return;const u=new URL(e.request.url);
 if(u.origin!==self.location.origin||u.pathname.startsWith('/api/')||u.pathname.startsWith('/.netlify/'))return;
 if(!['/','/content/physics.js','/content/physics-bank.js','/content/enhancements.js','/index.html','/assets/physics-formulas-ru.pdf','/assets/physics-formulas-kk.pdf','/manifest.json','/sw.js','/assets/cover-v8.png','/assets/cover-v9.png','/assets/icon.svg','/assets/icon-v9.png','/assets/icon-v9-32.png','/assets/icon-v9-192.png','/assets/icon-v9-512.png','/assets/icon-v9-maskable-512.png','/assets/apple-touch-v9.png','/assets/favicon-v9.ico'].includes(u.pathname))return;
 e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy))}return r}).catch(()=>caches.match(e.request)));
});
